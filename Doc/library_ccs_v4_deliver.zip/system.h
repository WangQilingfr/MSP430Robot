#ifndef SYSTEM_H
#define SYSTEM_H

#include "msp430g2553.h"
#include "intrinsics.h"
void Clock_graceInit_DCO_12M(void);

#endif


#ifndef SIDES_H
#define SIDES_H

#define LEFT 0
#define RIGHT 1
#define MAX_SIDES 2  //Size of vector for encoders

#endif

